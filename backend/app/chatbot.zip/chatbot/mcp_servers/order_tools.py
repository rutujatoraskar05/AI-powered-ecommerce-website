from mcp.server.fastmcp import FastMCP

mcp = FastMCP("orders")


@mcp.tool()
def track_order(
    order_id: int
):

    return f"Order {order_id} is processing"


if __name__ == "__main__":
    mcp.run()