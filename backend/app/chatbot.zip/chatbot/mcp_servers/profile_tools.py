from mcp.server.fastmcp import FastMCP

mcp = FastMCP("profile")


@mcp.tool()
def get_profile():

    return {
        "name": "Guest"
    }


if __name__ == "__main__":
    mcp.run()