from fastmcp import FastMCP
from services.product_service import ProductService

mcp = FastMCP("product")

@mcp.tool()
def search_products(
    brand:str="",
    category:str="",
    max_price:float=None
):
    return ProductService.search_products(
        brand,
        category,
        max_price
    )