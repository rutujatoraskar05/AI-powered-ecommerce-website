from mcp.server.fastmcp import FastMCP

mcp = FastMCP("wishlist")


@mcp.tool()
def view_wishlist():

    return []


if __name__ == "__main__":
    mcp.run()