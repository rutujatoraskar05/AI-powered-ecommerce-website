# chatbot/mcp_servers/mysql_tools.py

import sys
from pathlib import Path

# =========================
# Add Project Root Path
# =========================

ROOT_DIR = Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT_DIR))

# =========================
# Imports
# =========================

from mcp.server.fastmcp import FastMCP
from sqlalchemy import text

from database.db import SessionLocal

# =========================
# MCP Server
# =========================

mcp = FastMCP("mysql_server")


@mcp.tool()
def execute_query(query: str):
    """
    Execute SQL query on MySQL database.
    """

    db = SessionLocal()

    try:

        result = db.execute(text(query))

        # SELECT Query
        if query.strip().lower().startswith("select"):

            rows = result.fetchall()

            return [
                dict(row._mapping)
                for row in rows
            ]

        # INSERT / UPDATE / DELETE
        db.commit()

        return {
            "status": "success",
            "message": "Query executed successfully"
        }

    except Exception as e:

        db.rollback()

        return {
            "status": "error",
            "message": str(e)
        }

    finally:
        db.close()


@mcp.tool()
def hello():
    """
    MCP health check
    """

    return "MySQL MCP Server Working"


if __name__ == "__main__":
    print("Starting MySQL MCP Server...")
    mcp.run()