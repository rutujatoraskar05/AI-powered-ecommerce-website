# chatbot/mcp_servers/cart_tools.py

import os
import sys

# Go up to project root
ROOT_DIR = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        "..",
        "..",
        ".."
    )
)

sys.path.insert(0, ROOT_DIR)

from mcp.server.fastmcp import FastMCP
from sqlalchemy import text
from database.db import SessionLocal

mcp = FastMCP("cart")


@mcp.tool()
def show_cart(user_id: int):

    db = SessionLocal()

    try:

        query = """
        SELECT
            p.product_name,
            p.price,
            ci.quantity
        FROM cart_items ci
        JOIN carts c
            ON ci.cart_id = c.cart_id
        JOIN products p
            ON ci.product_id = p.product_id
        WHERE c.user_id = :user_id
        """

        rows = db.execute(
            text(query),
            {"user_id": user_id}
        ).fetchall()

        return [
            dict(row._mapping)
            for row in rows
        ]

    except Exception as e:
        return str(e)

    finally:
        db.close()


if __name__ == "__main__":
    print("Starting Cart MCP Server...")
    mcp.run()