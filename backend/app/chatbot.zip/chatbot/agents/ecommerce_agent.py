from langgraph.prebuilt import create_react_agent
from langchain_mcp_adapters.client import MultiServerMCPClient

from chatbot.llm import llm


async def get_agent():

    client = MultiServerMCPClient(
    {
        "mysql": {
            "command": "python",
            "args": ["chatbot/mcp_servers/mysql_tools.py"],
            "transport": "stdio"
        },

        "cart": {
            "command": "python",
            "args": ["chatbot/mcp_servers/cart_tools.py"],
            "transport": "stdio"
        },

        "order": {
            "command": "python",
            "args": ["chatbot/mcp_servers/order_tools.py"],
            "transport": "stdio"
        },

        "wishlist": {
            "command": "python",
            "args": ["chatbot/mcp_servers/wishlist_tools.py"],
            "transport": "stdio"
        },

        "profile": {
            "command": "python",
            "args": ["chatbot/mcp_servers/profile_tools.py"],
            "transport": "stdio"
        }
    }
)

    tools = await client.get_tools()

    agent = create_react_agent(
        llm,
        tools
    )

    return agent